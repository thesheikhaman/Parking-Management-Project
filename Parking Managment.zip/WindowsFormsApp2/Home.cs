﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QRCoder;
namespace WindowsFormsApp2
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }
        float two_wheeler=0;
        float four_wheeler=0;
        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void Home_Load(object sender, EventArgs e)
        {
            comboBox2.Items.Add("2-Wheelers");
            comboBox2.Items.Add("4-Wheelers");
            comboBox1.Items.Add("Cash");
            comboBox1.Items.Add("Other");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            dataGridView1.Columns.Add("", "");
            DataGridViewColumn column1 = dataGridView1.Columns[6];
            column1.Width = 120;
            DataGridViewColumn column2 = dataGridView1.Columns[7];
            column2.Width = 120;
            dataGridView1.Rows.Add("Session Id","Vehicle NO","Name","Type","Company","Model","ENtry time","Exit Time");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.BackColor = Color.Red;
            }
            if (textBox2.Text == "")
            {
                textBox2.BackColor = Color.Red;
            }
            if (comboBox2.SelectedItem == null)
            {
                comboBox2.BackColor = Color.Red;
            }
            if (textBox4.Text == "")
            {
                textBox4.BackColor = Color.Red;
            }
            if (textBox5.Text == "")
            {
                textBox5.BackColor = Color.Red;
            }
            if (textBox1.Text != "" && textBox2.Text != "" && textBox4.Text != "" && textBox5.Text != "" && comboBox2.SelectedItem != null && dateTimePicker1.Value != null)
            {
                int status = 0;
                try
                {
                    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                    con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                    con.Open();
                    System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                    com.Connection = con;
                    com.CommandText = "insert into current_data values(@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8)";
                    com.Parameters.AddWithValue("p1",Convert.ToInt32(label18.Text));
                    com.Parameters.AddWithValue("p2", textBox1.Text);
                    com.Parameters.AddWithValue("p3", textBox2.Text);
                    com.Parameters.AddWithValue("p4", comboBox2.SelectedItem.ToString());
                    com.Parameters.AddWithValue("p5", textBox4.Text);
                    com.Parameters.AddWithValue("p6", textBox5.Text);
                    com.Parameters.AddWithValue("p7", DateTime.Now);
                    com.Parameters.AddWithValue("p8",DateTime.Now);
                    com.ExecuteReader();
                    status = 1;
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to connect with database! or vehicle is already parked!");   
                }
                if (status == 1)
                {
                    try
                    {
                        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                        con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                        con.Open();
                        System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                        com.Connection = con;
                        com.CommandText = "insert into parking_data_all values(@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8)";
                        com.Parameters.AddWithValue("p1", Convert.ToInt32(label18.Text));
                        com.Parameters.AddWithValue("p2", textBox1.Text);
                        com.Parameters.AddWithValue("p3", textBox2.Text);
                        com.Parameters.AddWithValue("p4", comboBox2.SelectedItem.ToString());
                        com.Parameters.AddWithValue("p5", textBox4.Text);
                        com.Parameters.AddWithValue("p6", textBox5.Text);
                        com.Parameters.AddWithValue("p7", dateTimePicker1.Value);
                        com.Parameters.AddWithValue("p8", DateTime.Now);
                        com.ExecuteReader();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Unable to connect with database! or vehicle is already parked!");

                    }
                }
                button12_Click(sender, e);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.White;
            try
            {
                QRCodeGenerator qRCodeGenerator = new QRCodeGenerator();
                QRCodeData qRCodeData = qRCodeGenerator.CreateQrCode(textBox1.Text, QRCodeGenerator.ECCLevel.Q);
                QRCode qRCode = new QRCode(qRCodeData);
                Bitmap qrCodeImage = qRCode.GetGraphic(2);
                pictureBox1.Image = qrCodeImage;
            }
            catch (Exception)
            {
                //Do nothing
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.BackColor = Color.White;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.BackColor = Color.White;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.BackColor = Color.White;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox5.BackColor = Color.White;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "select * from current_data where vehicleno=@p1";
                com.Parameters.AddWithValue("p1", textBox6.Text);
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    label28.Text = dr[0].ToString();
                    label23.Text = "Vehicle Found!";    
                    label23.BackColor = Color.Green;
                    textBox10.Text = dr[2].ToString();//name
                    textBox9.Text = dr[6].ToString();//entry timee
                    textBox8.Text = DateTime.Now.ToString();//Exit time
                    TimeSpan timespan;
                    timespan = DateTime.Now - Convert.ToDateTime(dr[6]);
                    int diff = timespan.Minutes;
                    textBox7.Text =diff.ToString();//calculate parking time
                    float parking_time = Convert.ToSingle(textBox7.Text);//parking time float
                    parking_time = parking_time / 60;//per hour conversion
                    textBox7.Text = label26.Text = parking_time.ToString();
                    if(dr[3].ToString()== "2-Wheelers")
                    {
                        textBox11.Text = label27.Text = Convert.ToString(two_wheeler);
                        float fare = (two_wheeler*parking_time);
                        label25.Text = fare.ToString();
                    }
                    else
                    {
                        textBox11.Text = label27.Text = four_wheeler.ToString();
                        float fare = (four_wheeler * parking_time);
                        label25.Text = fare.ToString();
                    }
                    
                }
                else
                {
                    label23.Text = "Vehicle not Found!";
                    label23.BackColor = Color.Red;
                }
            }
            catch (Exception)
            {
                label23.Text = "Unable to connect with database";
                label23.BackColor = Color.Red;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button12_Click(sender, e);
            int value = 0;
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "SELECT COUNT(vehicleno) from current_data";
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    value = Convert.ToInt32(dr[0]);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database!");
                this.Close();
            }
            label15.Text = (1000 - value).ToString();//available slots;
            label16.Text = (value).ToString();

            int value1 = 0;
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "SELECT COUNT(vehicleno) from parking_data_all";
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    value1 = Convert.ToInt32(dr[0]);
                    label18.Text = value1.ToString();
                    label18.BackColor = Color.Yellow;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database!");
                this.Close();
            }
            //Fare Change
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "SELECT * from fare";
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    two_wheeler=Convert.ToSingle(dr[0]);
                    four_wheeler= Convert.ToSingle(dr[1]);
                    button4.Text = dr[0].ToString() + "PER HR.";
                    button5.Text = dr[1].ToString() + "PER HR.";
                }
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Rows.Add("Session Id", "Vehicle NO", "Name", "Type", "Company", "Model", "ENtry time", "Exit Time");
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "SELECT * from current_data";
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString());
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database!");
                this.Close();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(label23.Text== "Vehicle Found!")
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "delete from current_data where vehicleno=@p1";
                com.Parameters.AddWithValue("p1", textBox6.Text);
                com.ExecuteReader();
                label23.Text = "Vehicle not Found!";
                label23.BackColor = Color.Red;
                }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database! or Vehicle is not parked here !");
                
            }
            //WRITE FOR BILLING
            if (true)
                try
                {
                    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                    con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                    con.Open();
                    System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                    com.Connection = con;
                    com.CommandText = "insert into bill_data values(@p1,@p2,@p3,@p4)";
                    com.Parameters.AddWithValue("p1",Convert.ToInt32(label28.Text));
                    com.Parameters.AddWithValue("p2", Convert.ToSingle(label27.Text));
                    com.Parameters.AddWithValue("p3", Convert.ToSingle(label26.Text));
                    com.Parameters.AddWithValue("p4", Convert.ToSingle(label25.Text));
                    com.ExecuteReader();
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to connect with database! or Vehicle is not parked here !");
                    label23.Text = "Vehicle not Found!";
                    label23.BackColor = Color.Red;
                }
        }


        private void button13_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            fare_change fc = new fare_change();
            fc.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Two wheeler Price fare for One hour is :" + button4.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("four wheeler Price fare for One hour is :" + button5.Text);
        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 b = new Form1();
            b.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            search_Vehilce sv = new search_Vehilce();
            sv.Show();
        }
    }
}
