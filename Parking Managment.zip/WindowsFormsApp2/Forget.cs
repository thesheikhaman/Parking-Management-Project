﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Forget : Form
    {
        public Forget()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
            if(textBox3.Text=="")
            {
                textBox3.BackColor = Color.Red;
                button1.BackColor = Color.White;
            }
            if (textBox1.Text == "")
                {
                    textBox1.BackColor = Color.Red;
                    button1.BackColor = Color.White;
            }
            if (textBox2.Text == "")
            {
                textBox2.BackColor = Color.Red;
                button1.BackColor = Color.White;
            }

            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                try
                {
                    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                    con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                    con.Open();
                    System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                    com.Connection = con;
                    com.CommandText = "select username from login_details where name=@p1 and email=@p2 and fathername=@p3";
                    com.Parameters.AddWithValue("p1", textBox1.Text);
                    com.Parameters.AddWithValue("p2", textBox2.Text);
                    com.Parameters.AddWithValue("p3", textBox3.Text);
                    System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        listBox1.Items.Add(dr[0].ToString());
                    }
                    else
                    {
                        button1.BackColor = Color.White;
                        MessageBox.Show("User Not Registered!", "User Not REgistered!", MessageBoxButtons.OK);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to connect with database!");
                    button1.BackColor = Color.White;
                }
            }
            else
            {
                button1.BackColor = Color.White;
                MessageBox.Show("Enter Values! First");
            }
        }

        private void listBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "select password from login_details where username=@p1";
                com.Parameters.AddWithValue("p1", listBox1.SelectedItem.ToString());
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    label5.Text = dr[0].ToString();
                    label4.Text = listBox1.SelectedItem.ToString();
                    label4.BackColor = Color.Red;
                    label5.BackColor = Color.Green;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Failed to connect with database!");
            }
        }
        int i = 1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (label4.Text != "Your username ")
            {
                i++;
                //information will disaapear after TEN seconds

                while (i == 10)
                {
                    label5.ForeColor = Color.White;
                    label5.BackColor = Color.White;
                    label4.ForeColor = Color.White;
                    label4.BackColor = Color.White;
                    i++;
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                textBox1.BackColor = Color.White;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                textBox2.BackColor = Color.White;

            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text != "")
            {
                textBox3.BackColor = Color.White;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Forget_Load(object sender, EventArgs e)
        {

        }
    }
}
