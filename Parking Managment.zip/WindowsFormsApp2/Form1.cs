﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool print = false;
            String sessionid="", vehicleno="", name="", type="", company="", model="", entry="", exit="", fare="", amount="", total="";
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source =(localdb)\\MSSQLLocalDB;initial catalog=PROJECT;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "Select * from parking_data_all where Session_id=@p1";
                com.Parameters.AddWithValue("p1", Convert.ToInt32(textBox1.Text));//id
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                { 
                    sessionid= dr[0].ToString();
                    vehicleno= dr[1].ToString();
                    name= dr[2].ToString();
                    type= dr[3].ToString(); 
                    company= dr[4].ToString();
                    model= dr[5].ToString();
                    entry=dr[6].ToString();
                    exit= dr[7].ToString();
                    print= true;
                    
                }
            }
            catch (Exception)
            {
                MessageBox.Show("DataBAse Error");
                print = false;
            }
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source =(localdb)\\MSSQLLocalDB;initial catalog=PROJECT;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "Select * from bill_data where Session_id=@p1";
                com.Parameters.AddWithValue("p1", Convert.ToInt32(textBox1.Text));//id
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    fare = dr[1].ToString();
                    amount = dr[2].ToString();
                    total = dr[3].ToString();
                }
            }
            catch (Exception)
            {
                //do nothing
                print = false;
                MessageBox.Show("DataBAse Error");
            }
            if (print)
            {
                DataSet1_login_records ds = new DataSet1_login_records();
                ds.PRINT_BILL.Rows.Add(sessionid,vehicleno,name,type,company,model,entry,exit,fare,amount,total);
                //printing
                CrystalReport1 cr = new CrystalReport1();
                cr.SetDataSource(ds);
                bILL_PRINT p = new bILL_PRINT();
                p.crystalReportViewer1.ReportSource = cr;
                p.Show();
            }
            else
            {
                MessageBox.Show("Unable to print !!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
