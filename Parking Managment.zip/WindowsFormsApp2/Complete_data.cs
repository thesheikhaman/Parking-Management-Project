﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Complete_data : Form
    {
        public Complete_data()
        {
            InitializeComponent();
        }

        private void Complete_data_Load(object sender, EventArgs e)
        {

//preparing essentials things for showing the data in datagrid view
            dataGridView1.Columns.Add("", "");//1
            dataGridView1.Columns.Add("", "");//2
            dataGridView1.Columns.Add("", "");//3
            dataGridView1.Columns.Add("", "");//4
            dataGridView1.Columns.Add("", "");//5
            dataGridView1.Columns.Add("", "");//6
            dataGridView1.Columns.Add("", "");//7
            dataGridView1.Columns.Add("", "");//8
            dataGridView1.Rows.Add("Session Id", "Vehicle NO", "Name", "Type", "Company", "Model", "ENtry time", "Exit Time");
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source =(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "Select * from parking_data_all";
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                while (dr.Read())
                {
                    dataGridView1.Rows.Add(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString());
                }
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Do nothing
            label2.Text = DateTime.Now.ToString();
        }
    }
}
