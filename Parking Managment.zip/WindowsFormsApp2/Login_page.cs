﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace WindowsFormsApp2
{
    public partial class Login_page : Form
    {
        public Login_page()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.BackColor = Color.Red;
            }
            if (textBox2.Text == "")
            {
                textBox2.BackColor = Color.Red;
            }
            if (radioButton1.Checked || radioButton2.Checked&&textBox1.Text!=""&&textBox2.Text!="")
            {
                try
                {
                    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                    con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                    con.Open();
                    System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                    com.Connection = con;
                    com.CommandText = "select password from Login_details where username=@p1";
                    com.Parameters.AddWithValue("p1", textBox1.Text);
                    System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                    string pass = "";
                    if (dr.Read())
                    {
                        pass = dr[0].ToString();
                    }
                    if (pass == textBox2.Text)
                    {
                        try
                        {
                            System.Data.SqlClient.SqlConnection con1 = new System.Data.SqlClient.SqlConnection();
                            con1.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                            con1.Open();
                            System.Data.SqlClient.SqlCommand com1 = new System.Data.SqlClient.SqlCommand();
                            com1.Connection = con1;
                            com1.CommandText = "insert into login_records values(@p1,@p2)";
                            com1.Parameters.AddWithValue("p1", textBox1.Text);
                            com1.Parameters.AddWithValue("p2", DateTime.Now.ToString());
                            com1.ExecuteReader();
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Unable to connect with Database!");
                        }
                        if (radioButton1.Checked)
                        {
                            Home h = new Home();
                            h.Show();
                            
                        }
                        else
                        {
                            Admin a = new Admin();
                            a.Show();
                            
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password! (Try Again)");
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Some Error Occur! ,Try Again");
                }
            }
            else
            {
                MessageBox.Show("Please choose Type!");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Login_page_Load(object sender, EventArgs e)
        {
            
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(@"https://drive.google.com/file/d/1FpErKcLWdyhUmdli3iVyuNr05lcHdOAq/view?usp=sharing");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string password = textBox2.Text;
            Regex regex = new Regex(@"(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,15})$"); //For Combinations of numbers and alphabets
            Match match = regex.Match(password);
            if (match.Success)
            {
                label7.Text = "Correct pattern";
                label7.BackColor = Color.Green;
            }
            else
            {
                label7.Text = "Wrong pattern";
                label7.BackColor = Color.Red;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Forget f = new Forget();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(@"https://drive.google.com/file/d/1lAjvTPQ-82Gw
V6HZMe - v3HX5jaQp84rl / view ? usp = sharing");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(@"https://drive.google.com/file/d/1lAjvTPQ-82Gw
V6HZMe - v3HX5jaQp84rl / view ? usp = sharing");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
