﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class search_Vehilce : Form
    {
        public search_Vehilce()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label3.Text = "NOT Registered!";
            label3.BackColor = Color.Red;
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source =(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "Select * from parking_data_all where vehicleno=@p1";
                com.Parameters.AddWithValue("p1", textBox1.Text);//id
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    label3.Text = "Registered!";
                    label3.BackColor = Color.Green;

                    textBox2.Text = dr[0].ToString();
                    textBox3.Text = dr[2].ToString();
                    textBox4.Text = dr[3].ToString();
                    textBox5.Text = dr[4].ToString();
                    textBox6.Text = dr[5].ToString();
                    textBox7.Text = dr[6].ToString();
                    textBox8.Text = dr[7].ToString();

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Do nothing!");
                //do nothing
            }
        }

        private void search_Vehilce_Load(object sender, EventArgs e)
        {

        }
    }
}