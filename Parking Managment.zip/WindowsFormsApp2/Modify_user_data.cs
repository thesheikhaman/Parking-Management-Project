﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Modify_user_data : Form
    {
        public Modify_user_data()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "select username from login_details where username=@p1";
                com.Parameters.AddWithValue("p1", textBox1.Text);
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    label3.Text = "Username Find!";
                    label3.BackColor = Color.Green;
                }
                else
                {
                    label3.Text = "Username not find!";
                    label3.BackColor = Color.Red;
                    label8.BackColor = Color.Red;
                    label8.Text = "*Unable to read details from Database.";
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database", "Connection status");
            }
            if(label3.Text=="Username Find!")
            {
                try
                {
                    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                    con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                    con.Open();
                    System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                    com.Connection = con;
                    com.CommandText = "select * from login_details where username=@p1";
                    com.Parameters.AddWithValue("p1", textBox1.Text);
                    System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        label8.BackColor = Color.Green;
                        label8.Text = "*You can mAke changes below.";
                        textBox2.Text = dr[0].ToString();
                        textBox3.Text = dr[1].ToString();
                        textBox4.Text = dr[2].ToString();
                        dateTimePicker1.Value = Convert.ToDateTime(dr[3].ToString());
                    }
                    else
                    {
                        textBox2.Text = textBox3.Text = textBox4.Text = "";
                        dateTimePicker1.Value = DateTime.Now;
                    }
                }
                catch (Exception)
                {
                    label8.BackColor = Color.Red;
                    label8.Text = "*Unable to read details from Database.";
                }
            }
            else
            {
                textBox2.Text = textBox3.Text = textBox4.Text = "";
                dateTimePicker1.Value = DateTime.Now;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Modify_user_data_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "update login_details set name=@p2,fathername=@p3,email=@p4,dob=@p5 where username=@p1";
                com.Parameters.AddWithValue("p1", textBox1.Text);
                com.Parameters.AddWithValue("p2", textBox2.Text);
                com.Parameters.AddWithValue("p3", textBox3.Text);
                com.Parameters.AddWithValue("p4", textBox4.Text);
                com.Parameters.AddWithValue("p5", dateTimePicker1.Value);
                com.ExecuteReader();
                this.Close();
            }
            catch (Exception)
            {
                label8.BackColor = Color.Red;
                label8.Text = "*Unable to read/upDATE details from Database.";
            }
        }
    }
}
