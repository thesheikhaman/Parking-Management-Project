﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            user_add ua = new user_add();
            ua.Show();
        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Delete_a_user de_us = new Delete_a_user();
            de_us.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Modify_user_data mud = new Modify_user_data();
            mud.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            user_activity ua = new user_activity();
            ua.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            DataSet1_login_records ds = new DataSet1_login_records();
            DataSet1_login_recordsTableAdapters.login_recordsTableAdapter dta = new DataSet1_login_recordsTableAdapters.login_recordsTableAdapter();
            dta.Fill(ds.login_records);

            Print_user_login_records_crys rpt = new Print_user_login_records_crys();
            rpt.SetDataSource(ds);

            Print_users_login_records p = new Print_users_login_records();
            p.crystalReportViewer2.ReportSource = rpt;
            p.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr=MessageBox.Show("Are you sure want to Reset?", "MAster reset",MessageBoxButtons.YesNoCancel);
            if (dr == DialogResult.Yes)
            {
                DialogResult dr1 = MessageBox.Show("Are you sure want to Reset?", "MAster reset", MessageBoxButtons.YesNoCancel);
                if (dr1 == DialogResult.Yes)
                {
                    try
                    {
                        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                        con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                        con.Open();
                        System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                        com.Connection = con;
                        com.CommandText = "delete from current_data where session_id>=0";
                        com.CommandText = "delete from parking_data_all where session_id>=0";
                        com.CommandText = "delete from login_records";
                        com.CommandText = "delete from bill_data";
                        com.ExecuteReader();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Unable to connect with dataBase!");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Complete_data cd = new Complete_data();
            cd.Show();
        }
    }
}
