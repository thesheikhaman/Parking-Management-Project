﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Delete_a_user : Form
    {
        public Delete_a_user()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "select username from login_details where username=@p1";
                com.Parameters.AddWithValue("p1", textBox1.Text);
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    label3.Text = "Username Find!";
                    label3.BackColor = Color.Green;
                }
                else
                {
                    label3.Text = "Username not find!";
                    label3.BackColor = Color.Red;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database", "Connection status");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(label3.Text== "Username Find!" && label3.BackColor == Color.Green)
            {
                DialogResult result = MessageBox.Show("ARe you sure ??", "Delete:" + textBox1.Text, MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                        con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                        con.Open();
                        System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                        com.Connection = con;
                        com.CommandText = "Delete from login_details where username=@p1";
                        com.Parameters.AddWithValue("p1", textBox1.Text);
                        com.ExecuteReader();
                        DialogResult result1 = MessageBox.Show("User Deleted!","Deleted!",MessageBoxButtons.OK);
                        if (result1 == DialogResult.OK)
                        {
                            this.Close();
                        }

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Unable to connect with database", "Connection status");
                    }
                }
            }
        }

        private void Delete_a_user_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
