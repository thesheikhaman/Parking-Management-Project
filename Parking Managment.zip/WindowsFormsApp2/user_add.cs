﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions; //for REgex

namespace WindowsFormsApp2
{
    public partial class user_add : Form
    {
        public user_add()
        {
            InitializeComponent();
        }
        Boolean password_status = false, email_status = false, username_avail_status = false;

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
                textBox2.BackColor = Color.White;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string email = textBox3.Text;
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
            {
                textBox3.BackColor = Color.White;
                label7.Text = "Email is Valid!";
                label7.BackColor = Color.Green;
                email_status = true;
            }
            else
            {
                label7.Text = "Email is invalid!";
                label7.BackColor = Color.Red;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                con.Open();
                System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                com.Connection = con;
                com.CommandText = "select username from login_details where username=@p1";
                com.Parameters.AddWithValue("p1", textBox4.Text);
                System.Data.SqlClient.SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    label8.Text = "Username Unavailable!";
                    label8.BackColor = Color.Red;
                }
                else
                {
                    textBox4.BackColor = Color.White;
                    label8.Text = "Username Available!";
                    label8.BackColor = Color.Green;
                    username_avail_status = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to connect with database", "Connection status");
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string password = textBox5.Text;
            Regex regex = new Regex(@"(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{8,15})$"); //For Combinations of numbers and alphabets
            Match match = regex.Match(password);
            if (match.Success)
            {
                textBox5.BackColor = Color.White;
                label9.Text = "Password is Valid!";
                label9.BackColor = Color.Green;
                password_status = true;
            }
            else
            {
                label9.Text = "Password is invalid!";
                label9.BackColor = Color.Red;
            }
        }

        private void user_add_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
                textBox1.BackColor = Color.White;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.BackColor = Color.Red;
            }
            if (textBox2.Text == "")
            {
                textBox2.BackColor = Color.Red;
            }
            if (textBox3.Text == "")
            {
                textBox3.BackColor = Color.Red;
            }
            if (textBox4.Text == "")
            {
                textBox4.BackColor = Color.Red;
            }
            if (textBox5.Text == "")
            {
                textBox5.BackColor = Color.Red;
            }
            else if(textBox1.Text!=""&& textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && password_status == true && email_status == true && username_avail_status == true)
            {
                try {
                    System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
                    con.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;initial catalog=project;integrated security=true";
                    con.Open();
                    System.Data.SqlClient.SqlCommand com = new System.Data.SqlClient.SqlCommand();
                    com.Connection = con;
                    com.CommandText = "insert into login_details values(@p1,@p2,@p3,@p4,@p5,@p6)";
                    com.Parameters.AddWithValue("p1", textBox1.Text);//name
                    com.Parameters.AddWithValue("p2", textBox2.Text);//father_name
                    com.Parameters.AddWithValue("p3", textBox3.Text);//e mail
                    com.Parameters.AddWithValue("p4", dateTimePicker1.Value);//dob
                    com.Parameters.AddWithValue("p5", textBox4.Text);//username
                    com.Parameters.AddWithValue("p6", textBox5.Text);//Password
                    com.ExecuteReader();
                    DialogResult result = MessageBox.Show("User data has been saved", "Status of add user", MessageBoxButtons.OK);
                    if (result == DialogResult.OK)
                    {
                        this.Close();
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Unable to connect with database", "Connection status");
                }
            }
        }
    }
}
